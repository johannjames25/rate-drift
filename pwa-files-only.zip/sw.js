const CACHE_NAME = "rate-drift-shell-v1";
const SHELL_FILES = [
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Never cache the live rate API — the whole point of the tool is a fresh number.
  if (url.hostname === "api.frankfurter.dev") {
    event.respondWith(fetch(event.request));
    return;
  }

  // App shell: cache-first, so the tool opens instantly and works offline
  // (you'll still need a connection for a live rate check).
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
